var app = angular.module('galatea', ['nvd3']);


