//Importar librerías
import scala.collection.mutable.ArrayBuffer
import scala.io.Source
import org.apache.spark._
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.{SQLContext,Row}
import org.apache.spark.ml.feature.StringIndexer
import org.apache.spark.ml.feature.VectorAssembler
import org.apache.spark.sql.functions._
import org.apache.spark.mllib.linalg.{DenseVector,Vector}
import org.apache.spark.mllib.evaluation.BinaryClassificationMetrics
import org.apache.spark.ml.feature.{Normalizer,StandardScaler}
import org.apache.spark.sql.Row
import org.apache.spark.sql.types._


//Leer datos y ajustar para su procesamiento
case class Obs( id: Float, v17: Float, v19: Float, 
	v20: Float, v23: Float, v24: Float, v26: Float, v29: Float)

def parseObs(line: Array[Float]): Obs = {
    Obs( line(0), line(1), line(2), line(3), line(4), line(5), line(6), line(7)  )     }
	
def parseRDD(rdd: RDD[String]): RDD[Array[Float]] = {
    rdd.map(_.split(",")).map(_.drop(0)).map(_.map(_.toFloat))}

val rdd = sc.textFile("/home/edgar/Escritorio/DataIPS/table4.txt")
val obsRDD = parseRDD(rdd).map(parseObs)
val obsDF = obsRDD.toDF().cache()
obsDF.registerTempTable("obs")



val featureCols = Array("v17","v19","v20","v23","v24","v26","v29")
val assembler = new VectorAssembler().setInputCols(featureCols).setOutputCol("features")
val df2 = assembler.transform(obsDF)


/*
//------------------------------------------------------------//
import org.apache.spark.ml.clustering.KMeans


val besterror  	  = new ArrayBuffer[Double]()
val numcluster    = new ArrayBuffer[Double]()



besterror += (1e100)
// Trains a k-means model.
for(i<-  2 to 50)
{
	val kmeans = new KMeans().setK(i).setSeed(1L)
	val model = kmeans.fit(df2)
	
	// Evaluate clustering by computing Within Set Sum of Squared Errors.
	val WSSSE = model.computeCost(df2)
	
	if (WSSSE < besterror.last)
	{
		besterror += WSSSE
		numcluster += i 		
	}

	
}
 	
val kmeans = new KMeans().setK(numcluster.last.toInt).setSeed(1L)
val model = kmeans.fit(df2)

df2.show

// Evaluate clustering by computing Within Set Sum of Squared Errors.
val WSSSE = model.computeCost(df2)
println(s"Within Set Sum of Squared Errors = $WSSSE")

// Shows the result.
println("Cluster Centers: ")
model.clusterCenters.foreach(println)
*/