//Importar librerías
import scala.collection.mutable.ArrayBuffer
import scala.io.Source
import org.apache.spark._
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.{SQLContext,Row}
import org.apache.spark.ml.feature.StringIndexer
import org.apache.spark.ml.feature.VectorAssembler
import org.apache.spark.sql.functions._
import org.apache.spark.mllib.linalg.{DenseVector,Vector}
import org.apache.spark.mllib.evaluation.BinaryClassificationMetrics
import org.apache.spark.ml.feature.{Normalizer,StandardScaler}
import org.apache.spark.sql.Row
import org.apache.spark.sql.types._


//Leer datos y ajustar para su procesamiento
case class Obs( id: Float, v17: Float, v19: Float, 
	v20: Float, v23: Float, v24: Float, v26: Float, v29: Float)

def parseObs(line: Array[Float]): Obs = {
    Obs( line(0), line(1), line(2), line(3), line(4), line(5), line(6), line(7)  )     }
	
def parseRDD(rdd: RDD[String]): RDD[Array[Float]] = {
    rdd.map(_.split(",")).map(_.drop(0)).map(_.map(_.toFloat))}

val rdd = sc.textFile("/home/edgar/Escritorio/DataIPS/table2.txt")
val obsRDD = parseRDD(rdd).map(parseObs)
val obsDF = obsRDD.toDF().cache()
obsDF.registerTempTable("obs")



val featureCols = Array("v17","v19","v20","v23","v24","v26","v29")
val assembler = new VectorAssembler().setInputCols(featureCols).setOutputCol("features")
val df2 = assembler.transform(obsDF)

//FOS per variable
 df2.describe("v17","v19","v20","v23","v24","v26","v29").show

 
 //Correlation and covatiance per variable
 df2.stat.corr("v23","v24")
 df2.stat.cov("v23","v24")

 //Transpose df2
 val df = df2.select("id","v17","v19","v20","v23","v24","v26","v29")

 
 val kv = explode(array(df.columns.tail.map { 
  c => struct(lit(c).alias("k"), col(c).alias("v")) 
}: _*))
	
val df3 = df  .withColumn("kv", kv).
	select($"id", $"kv.k", $"kv.v").
	groupBy($"k")  .
	pivot("id").agg(first($"v"))  .
	orderBy($"k")  .
	withColumnRenamed("k", "vals") .
	withColumnRenamed("1.0", "ips1") .
	withColumnRenamed("2.0", "ips2") .
	withColumnRenamed("3.0", "ips3") .
	withColumnRenamed("4.0", "ips4") .
	withColumnRenamed("5.0", "ips5") .
	withColumnRenamed("6.0", "ips6") .
	withColumnRenamed("7.0", "ips7") .
	withColumnRenamed("8.0", "ips8") .
	withColumnRenamed("9.0", "ips9") .
	withColumnRenamed("10.0", "ips10") .
	withColumnRenamed("11.0", "ips11") .
	withColumnRenamed("12.0", "ips12") .
	withColumnRenamed("13.0", "ips13") .
	withColumnRenamed("14.0", "ips14") .
	withColumnRenamed("15.0", "ips15") .
	withColumnRenamed("16.0", "ips16") .
	withColumnRenamed("17.0", "ips17") .
	withColumnRenamed("18.0", "ips18") .
	withColumnRenamed("19.0", "ips19") .
	withColumnRenamed("20.0", "ips20") 

 df2.describe("ips1","ips2","ips3","ips4","ips5","ips6","ips7","ips8",
	"ips9","ips10","ips11","ips12","ips13","ips14","ips15",
	"ips16","ips17","ips18","ips19","ips20").show

