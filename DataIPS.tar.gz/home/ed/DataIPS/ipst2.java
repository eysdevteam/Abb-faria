//Importar librerías
import scala.collection.mutable.ArrayBuffer
import scala.io.Source
import org.apache.spark._
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.{SQLContext,Row}
import org.apache.spark.ml.feature.StringIndexer
import org.apache.spark.ml.feature.VectorAssembler
import org.apache.spark.sql.functions._
import org.apache.spark.mllib.linalg.{DenseVector,Vector}
import org.apache.spark.mllib.evaluation.BinaryClassificationMetrics
import org.apache.spark.ml.feature.{Normalizer,StandardScaler}
import org.apache.spark.sql.Row
import org.apache.spark.sql.types._
import org.apache.spark.ml.feature.PCA
import org.apache.spark.mllib.linalg.SingularValueDecomposition


//Leer datos y ajustar para su procesamiento
case class Obs( id: Float, v17: Float, v19: Float, 
	v20: Float, v23: Float, v24: Float, v26: Float, v29: Float)

def parseObs(line: Array[Float]): Obs = {
    Obs( line(0), line(1), line(2), line(3), line(4), line(5), line(6), line(7)  )     }
	
def parseRDD(rdd: RDD[String]): RDD[Array[Float]] = {
    rdd.map(_.split(",")).map(_.drop(0)).map(_.map(_.toFloat))}

val rdd = sc.textFile("/home/edgar/Escritorio/DataIPS/table2.txt")
val obsRDD = parseRDD(rdd).map(parseObs)
val obsDF = obsRDD.toDF().cache()
obsDF.registerTempTable("obs")



val featureCols = Array("v17","v19","v24","v29")
val assembler = new VectorAssembler().setInputCols(featureCols).setOutputCol("featuresPCA")
val df2 = assembler.transform(obsDF)

val pca = new PCA().setInputCol("featuresPCA").
  setOutputCol("features").
  setK(2).
  fit(df2)

val result = pca.transform(df2).select("features")
result.show(false)//no limitar la vista


//------------------------------------------------------------//
import org.apache.spark.ml.clustering.GaussianMixture

val besterror  	  = new ArrayBuffer[Double]()
val numcluster    = new ArrayBuffer[Int]()
val error     = new ArrayBuffer[Double]()

besterror += (0)
for(i<-  2 to 20)
{
	// Trains Gaussian Mixture Model
	val gmm = new GaussianMixture().setK(i)
	val model = gmm.fit(result)
	error += model.summary.logLikelihood
	
	if (model.summary.logLikelihood> besterror.last)
	{
		besterror  += model.summary.logLikelihood
		numcluster += i 		
	}
}
	
	// Trains Gaussian Mixture Model
	val gmm = new GaussianMixture().setK(5)
	val model = gmm.fit(result)
	
// output parameters of mixture model model
for (i <- 0 until model.getK) {
  println(s"Gaussian $i:\nweight=${model.weights(i)}\n" +
      s"mu=${model.gaussians(i).mean}\nsigma=\n${model.gaussians(i).cov}\n")
}




 	
	
