//Importar librerías
import scala.collection.mutable.ArrayBuffer
import scala.io.Source
import org.apache.spark._
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.{SQLContext,Row}
import org.apache.spark.ml.feature.StringIndexer
import org.apache.spark.ml.feature.VectorAssembler
import org.apache.spark.sql.functions._
import org.apache.spark.mllib.linalg.{DenseVector,Vector}
import org.apache.spark.mllib.linalg.{Vectors, Vector}
import org.apache.spark.mllib.linalg.distributed.RowMatrix
import org.apache.spark.mllib.evaluation.BinaryClassificationMetrics
import org.apache.spark.ml.feature.{Normalizer,StandardScaler}
import org.apache.spark.sql.Row
import org.apache.spark.sql.types._
import org.apache.spark.ml.feature.PCA
import org.apache.spark.mllib.linalg.SingularValueDecomposition
import org.apache.spark.mllib.linalg.Matrix
import org.apache.spark.mllib.linalg.Matrices



//Leer datos y ajustar para su procesamiento
case class Obs2( v17: Float, v19: Float, 
	v20: Float, v23: Float, v24: Float, v26: Float, v29: Float)

def parseObs2(line: Array[Float]): Obs2 = {
    Obs2( line(0), line(1), line(2), line(3), line(4), line(5), line(6)  )     }
	
def parseRDD2(rdd: RDD[String]): RDD[Array[Float]] = {
    rdd.map(_.split(",")).map(_.drop(0)).map(_.map(_.toFloat))}

val rdd2 = sc.textFile("/home/edgar/Escritorio/DataIPS/table11.txt")


val data = rdd2.map(s => Vectors.dense(s.split(',').map(_.toDouble)))
val mat: RowMatrix = new RowMatrix(data)
val svd: SingularValueDecomposition[RowMatrix, Matrix] = mat.computeSVD(4, computeU = true)
val U: RowMatrix = svd.U  // The U factor is a RowMatrix.
val s: Vector = svd.s     // The singular values are stored in a local dense vector.
val V: Matrix = svd.V     // The V factor is a local dense matrix

val dm = Matrices.diag(s)
val us = U.multiply(dm)
val usv = us.multiply(V.transpose)

val dat=usv.rows.map(x=> x.toArray.mkString(","))
dat.coalesce(1,true).saveAsTextFile("SVD4")

//////////7
//Leer datos y ajustar para su procesamiento
//Leer datos y ajustar para su procesamiento
case class Obs( v17: Float, v19: Float, 
	v20: Float, v23: Float, v24: Float, v26: Float, v29: Float)

def parseObs(line: Array[Float]): Obs = {
    Obs( line(0), line(1), line(2), line(3), line(4), line(5), line(6)  )     }
	
def parseRDD(rdd: RDD[String]): RDD[Array[Float]] = {
    rdd.map(_.split(",")).map(_.drop(0)).map(_.map(_.toFloat))}

val rdd = sc.textFile("/home/edgar/SVD4/part-00000")
val obsRDD = parseRDD(rdd).map(parseObs)
val obsDF = obsRDD.toDF().cache()
obsDF.registerTempTable("obs")


val featureCols = Array("v17","v19","v20","v23","v24","v26","v29")
val assembler = new VectorAssembler().setInputCols(featureCols).setOutputCol("features")
val df2 = assembler.transform(obsDF)



import org.apache.spark.ml.clustering.KMeans


val besterror  	  = new ArrayBuffer[Double]()
val numcluster    = new ArrayBuffer[Double]()



besterror += (1e100)
// Trains a k-means model.
for(i<-  2 to 20)
{
	val kmeans = new KMeans().setK(i)
		val model = kmeans.fit(df2)
	
	// Evaluate clustering by computing Within Set Sum of Squared Errors.
	val WSSSE = model.computeCost(df2)
	
	if (WSSSE < besterror.last)
	{
		besterror += WSSSE
		numcluster += i 		
	}

}
 	
val kmeans = new KMeans().setK(5)
val model = kmeans.fit(df2)

df2.show

// Evaluate clustering by computing Within Set Sum of Squared Errors.
val WSSSE = model.computeCost(df2)
println(s"Within Set Sum of Squared Errors = $WSSSE")

// Shows the result.
println("Cluster Centers: ")
model.clusterCenters.foreach(println)
model.summary.predictions.show

//------------------------------------------------------------//
import org.apache.spark.ml.clustering.GaussianMixture

val besterror2  	  = new ArrayBuffer[Double]()
val numcluster2    = new ArrayBuffer[Int]()
val error2     = new ArrayBuffer[Double]()

besterror2 += (0)
for(i<-  2 to 20)
{
	// Trains Gaussian Mixture Model
	val gmm = new GaussianMixture().setK(i)
	val model = gmm.fit(df2)
	error2 += model.summary.logLikelihood
	
	if (model.summary.logLikelihood> besterror2.last)
	{
		besterror2  += model.summary.logLikelihood
		numcluster2 += i 		
	}
}
	
	// Trains Gaussian Mixture Model
	val gmm = new GaussianMixture().setK(5)
	val model2 = gmm.fit(df2)
	
// output parameters of mixture model model
for (i <- 0 until model2.getK) {
  println(s"Gaussian $i:\nweight=${model2.weights(i)}\n" +
      s"mu=${model2.gaussians(i).mean}\nsigma=\n${model2.gaussians(i).cov}\n")
}



	
